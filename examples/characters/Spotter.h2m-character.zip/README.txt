A character for the narrated-slides studio: Spotter.
In the Studio, open Settings > Media library and choose "Import a character", then pick this file. It brings in the character, his action clips and his voice setting.
